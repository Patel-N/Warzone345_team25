#include "Player.h"
#include "Territory.h"
#include "Hand.h"
#include "Order.h"
#include <cstddef>


class Player
{
    Territory* Territoryptr[]; // list of territory
    Hand* Handptr;// pointer to a hand of cards
    Order* Orderptr[];// list of orders

    Territory* toDefend() {
        return  { territory1,territory2 }; // returns territory pointers of territory to defend
    };
    Territory* toAttack() {
        return  { territory3,territory4 }; // returns territory pointers of territory to attack
    };
    void issueOrder() {   
       Order *Orderptr = new Order; // creating new order
       Orderptr[0]= *Orderptr; // adding it to the list of Order

    };
};